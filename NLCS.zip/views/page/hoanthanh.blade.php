@extends('master')
@section('content1')

<div class="row">
    <div class="col-md-12">

        <h3>
            <font color="#FF9600" style="margin-left:12%"> Đặt hàng thành công xin cảm ơn quý khách đã mua hành của cửa hàng chúng tôi!</font>
        </h3>
        <ol style="margin-left:5%; list-style-type: circle">
            <li> Hóa đơn mua hàng của quý khách đã được chuyển đến địa chỉ email của quý khách.
            </li>
            <li> Hóa đơn mua hàng của quý khách đã được chuyển đến địa chỉ có trong lihần thông tin khách hàng, thời gian giao hàng từ 2 đén 3 ngày, tính từ khi xác nhận đơn hàng.
            </li>
            <li>Chúng tôi sẽ liên hệ với quý khách để xác nhận đơn hàng trong vòng 24h.
            </li>
            <li>Chân thành cảm ơn quý khách đã sử dụng sản lihẩm của chúng tôi.
            </li>
            <li style="color:red"> Đường day nóng: 0907338376 hoặc email:trunghieu.lth1998@gmail.com
        </ol>
        </ul>

    </div>
</div>
@endsection