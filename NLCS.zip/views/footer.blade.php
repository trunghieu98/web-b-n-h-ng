<div class="footer">
    <div class=" container">
        <div class="footer-size">
            <div class="row">
                <div class="footer-center">
                    <div class="col-md-4">Contact</div>
                    <div class="col-md-4"> Phản hồi</div>
                    <div class="col-md-4"> Follow US</div>
                </div>
            </div>

        </div>
        <div class="mtop-footer">
            <div class="row">
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-4">
                            <ul>
                                <li>
                                    <a href="#">Liên hệ:</a>
                                </li>
                                <li class="mt-mb">
                                    <a href="#">Email:</a>
                                </li>
                                <li>
                                    <a href="#">Địa chỉ</a>
                                </li>
                            </ul>

                        </div>
                        <div class="col-md-8">
                            <ul>
                                <li>
                                    <a href="#">+84907338376</a>
                                </li>
                                <li class="mt-mb">
                                    <a href="#">trunghieu.lth1998@gmail.com</a>
                                </li>
                                <li>
                                    <a href="#">Ly Thuong Ket Street,Cai Rang
                                        District,Can Tho City</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <form action="#" method="post">
                        <fieldset>
                            <input type="text" class="theinput"> <br>


                            <button class="thebutton">
                                Submit
                            </button>
                        </fieldset>
                    </form>
                </div>
                <div class="col-md-4">
                    <div>
                        <div class="row">
                            <div class="col-md-4">
                                <ul>
                                    <li>
                                        <a href="#"><i class="fab fa-facebook"></i></a>

                                    </li>
                                    <li>
                                        <a href="#">Zalo</a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="fab fa-twitter"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-8">
                                <ul>
                                    <li>
                                        <a href="#">Fanpage</a>

                                    </li>
                                    <li>
                                        <a href="#">Zalo Page</a>
                                    </li>
                                    <li>
                                        <a href="#">Intergram</a>
                                    </li>
                                    <li>
                                        <a href="#">Twitter</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="divbottom">
        <a href="">
            Design by A&B
        </a>
    </div>
</div> 