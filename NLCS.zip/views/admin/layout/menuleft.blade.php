<div class="col-sm-3 col-md-2 sidebar">
    <ul class="nav nav-sidebar">
        <li class="active"><a>QUẢN Lý <span class="sr-only">(current)</span></a></li>
        <li><a href="{{route('themloaisanpham')}}">Loại sản phẩm</a></li>
        <li><a href="{{route('postthemnhasanxuat')}}">Nhà sản xuất</a></li>

    </ul>
    <ul class="nav nav-sidebar">
        <li><a href="{{route('themsanpham')}}">Sản phẩm</a></li>
        <li><a href="{{route('themquangcao')}}">Quảng cáo</a></li>
        <li><a href="{{route('themtaikhoan')}}">Tài khoản</a></li>
        <li><a href=""></a></li>
    </ul>
    <ul class="nav nav-sidebar">
        <li><a href="{{route('themkm')}}">Khuyến mãi</a></li>
        <li><a href="{{route('cuahang')}}">Cửa hàng chi nhánh</a></li>
        <li><a href="">Another nav item</a></li>
    </ul>
</div>